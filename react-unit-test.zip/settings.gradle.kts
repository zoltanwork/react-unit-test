
rootProject.name = "react-unit-test"

